package com.treeminder.dao;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;

import java.util.ArrayList;
import java.util.List;



import com.treeminder.model.Register;


public class RegisterDAO {
	
	// Hash password using SHA-256
    private static String hashPassword(String password) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] hashedBytes = md.digest(password.getBytes());
            StringBuilder sb = new StringBuilder();
            for (byte b : hashedBytes) {
                sb.append(String.format("%02x", b));
            }
            return sb.toString();
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("Error hashing password", e);
        }
    }

    // Register new user
	public static boolean register(String fname, String lname, String username,
            String email, String rawPassword, String role,
            String mobile, String parish, String nursery) {
		
			String hashedPassword = hashPassword(rawPassword);

		
String sql = "INSERT INTO register (firstname, lastname, username, email, password_hash, role, mobile, parish, nursery, created_at) " +
"VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())";

        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {

        	 ps.setString(1, fname);
             ps.setString(2, lname);
             ps.setString(3, username);
             ps.setString(4, email);
             ps.setString(5, hashedPassword); 
             ps.setString(6, role);
             ps.setString(7, mobile);
             ps.setString(8, parish);
             ps.setString(9, nursery);
             
             int result = ps.executeUpdate();
            System.out.println("User registered: " + username + ". Rows affected: " + result);
            return result == 1;

        } catch (SQLException e) {
            System.err.println("Error registering user: " + username);
            e.printStackTrace();  // log properly later
            return false;
        }
    }

	 public static Register validate(String username, String rawPassword) throws SQLException {
		    System.out.println("Validating user in database: " + username);
		    
		    String hashedPassword = hashPassword(rawPassword);
	        String sql = "SELECT * FROM register WHERE username = ? AND password_hash = ?";
		    
		    try (Connection c = DBConnection.getConnection();
		         PreparedStatement ps = c.prepareStatement(sql)) {

		    	  ps.setString(1, username);
		          ps.setString(2, hashedPassword);
		            
		          try (ResultSet rs = ps.executeQuery()) {
		                if (rs.next()) {
		                    System.out.println("User authenticated: " + username);

		                    // Build Register model from DB row
		                    Register r = new Register();
		                    r.setId(rs.getInt("id"));
		                    r.setFirstname(rs.getString("firstname"));
		                    r.setLastname(rs.getString("lastname"));
		                    r.setUsername(rs.getString("username"));
		                    r.setEmail(rs.getString("email"));
		                    r.setRole(rs.getString("role"));
		                    r.setMobile(rs.getString("mobile"));
		                    r.setParish(rs.getString("parish"));
		                    r.setNursery(rs.getString("nursery"));

		                    Timestamp createdTs = rs.getTimestamp("created_at");
		                    if (createdTs != null) r.setCreated_at(createdTs.toLocalDateTime());

		                    System.out.println("Database login successful for user: " + username);
		                    return r;
		                } else {
		                    System.out.println("Invalid credentials for user: " + username);
		                }
		            }
		        } catch (SQLException e) {
		            System.err.println("Error validating user: " + username);
		            throw e;
		        }
		        return null;
		    }

		    // List all registered users (for admin) - ADD DEBUG OUTPUT
		    public static List<Register> listAll() throws SQLException {
		        List<Register> list = new ArrayList<>();
		        String sql = "SELECT id, firstname, lastname, username, email, role, mobile, parish, nursery, created_at " +
		                     "FROM register ORDER BY created_at DESC";
		        
		        System.out.println("=== DEBUG: Fetching all users from database ===");
		        
		        try (Connection c = DBConnection.getConnection();
		             PreparedStatement ps = c.prepareStatement(sql);
		             ResultSet rs = ps.executeQuery()) {
		             
		            int count = 0;
		            while (rs.next()) {
		                count++;
		                // DEBUG: Print what we're getting from database
		                System.out.println("User " + count + " - ID: " + rs.getInt("id") + 
		                                 ", Firstname: " + rs.getString("firstname") +
		                                 ", Lastname: " + rs.getString("lastname") +
		                                 ", Mobile: " + rs.getString("mobile") +
		                                 ", Parish: " + rs.getString("parish") +
		                                 ", Nursery: " + rs.getString("nursery"));

		                Register r = new Register();
		                r.setId(rs.getInt("id"));
		                r.setFirstname(rs.getString("firstname"));
		                r.setLastname(rs.getString("lastname"));
		                r.setUsername(rs.getString("username"));
		                r.setEmail(rs.getString("email"));
		                r.setRole(rs.getString("role"));
		                r.setMobile(rs.getString("mobile"));
		                r.setParish(rs.getString("parish"));
		                r.setNursery(rs.getString("nursery"));

		                // Set created_at
		                Timestamp created = rs.getTimestamp("created_at");
		                if (created != null) r.setCreated_at(created.toLocalDateTime());

		                list.add(r);
		            }
		            System.out.println("Retrieved " + count + " users from database");
		        } catch (SQLException e) {
		            System.err.println("Error fetching users list: " + e.getMessage());
		            throw e;
		        }
		        return list;
		    }

		    // Remove user
		    public static boolean removeUser(int id) throws SQLException {
		        String sql = "DELETE FROM register WHERE id = ?";
		        try (Connection c = DBConnection.getConnection();
		             PreparedStatement ps = c.prepareStatement(sql)) {
		            ps.setInt(1, id);
		            int result = ps.executeUpdate();
		            System.out.println("User removed. ID: " + id + ", Rows affected: " + result);
		            return result == 1;
		        } catch (SQLException e) {
		            System.err.println("Error removing user ID: " + id);
		            throw e;
		        }
		    }

		    // Check if username exists
		    public static boolean usernameExists(String username) throws SQLException {
		        String sql = "SELECT COUNT(*) FROM register WHERE username = ?";
		        try (Connection c = DBConnection.getConnection();
		             PreparedStatement ps = c.prepareStatement(sql)) {
		            ps.setString(1, username);
		            try (ResultSet rs = ps.executeQuery()) {
		                if (rs.next()) {
		                    return rs.getInt(1) > 0;
		                }
		            }
		        }
		        return false;
		    }
		

    // Update last login time (for user_activity table)
    public static void updateLastLogin(int userId) throws SQLException {
        String sql = "UPDATE user_activity SET last_login = NOW() WHERE user_id = ?";
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, userId);
            ps.executeUpdate();
        }
    }
}