package com.treeminder.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {
	 // Azure MySQL connection details
    private static final String DB_URL  = "jdbc:mysql://treeplantingdatabseserver.mysql.database.azure.com:3306/treeminder?useSSL=true&requireSSL=true";
    private static final String DB_USER = "Treeminder";
    private static final String DB_PASS = "Software@876";

    /**
     * Get a connection to the Azure MySQL database
     */
    public static Connection getConnection() throws SQLException {
        try {
            // Load MySQL driver (optional for modern JDBC but safe to keep)
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            System.err.println("MySQL JDBC Driver not found.");
            e.printStackTrace();
        }

        // Return active DB connection
        return DriverManager.getConnection(DB_URL, DB_USER, DB_PASS);
    }

    // Simple test to confirm connection
    public static void main(String[] args) {
        try (Connection conn = DBConnection.getConnection()) {
            if (conn != null) {
                System.out.println("Connected to Azure MySQL successfully!");
            } else {
                System.out.println("Failed to connect to Azure MySQL.");
            }
        } catch (SQLException e) {
            System.err.println("Database connection error:");
            e.printStackTrace();
        }
    }
}