package com.treeminder.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.treeminder.model.User_activity;

public class User_activityDAO {

    // Insert a login event
	 public static void logLogin(int userId) throws SQLException {
	        String sql = "INSERT INTO user_activity (user_id, last_login, status, action) VALUES (?, NOW(), 'active', 'login')";
	        try (Connection c = DBConnection.getConnection();
	             PreparedStatement ps = c.prepareStatement(sql)) {
	            ps.setInt(1, userId);
	            int rowsAffected = ps.executeUpdate();
	            System.out.println("Login logged for user ID " + userId + ". Rows affected: " + rowsAffected);
	        } catch (SQLException e) {
	            System.err.println("Error logging login for user ID " + userId);
	            throw e;
	        }
	    }


	    // Update logout time + calculate time spent - matches your schema
	    public static void logLogout(int userId) throws SQLException {
	        // First get the last login time
	        String getLoginSql = "SELECT last_login FROM user_activity WHERE user_id = ? AND action = 'login' ORDER BY last_login DESC LIMIT 1";
	        try (Connection c = DBConnection.getConnection();
	             PreparedStatement ps = c.prepareStatement(getLoginSql)) {
	            ps.setInt(1, userId);
	            try (ResultSet rs = ps.executeQuery()) {
	                if (rs.next()) {
	                    java.sql.Timestamp lastLogin = rs.getTimestamp("last_login");
	                    if (lastLogin != null) {
	                        long timeSpentSeconds = (System.currentTimeMillis() - lastLogin.getTime()) / 1000;
	                        
	                        // Insert logout record
	                        String logoutSql = "INSERT INTO user_activity (user_id, last_login, total_time_spent_seconds, status, action) " +
	                                         "VALUES (?, NOW(), ?, 'inactive', 'logout')";
	                        try (PreparedStatement logoutStmt = c.prepareStatement(logoutSql)) {
	                            logoutStmt.setInt(1, userId);
	                            logoutStmt.setLong(2, timeSpentSeconds);
	                            logoutStmt.executeUpdate();
	                            System.out.println("Logout logged for user ID " + userId + ". Time spent: " + timeSpentSeconds + " seconds");
	                        }
	                    }
	                }
	            }
	        } catch (SQLException e) {
	            System.err.println("Error logging logout for user ID " + userId);
	            throw e;
	        }
	    }

	    // List all logs (for admin view) - matches your schema
	    public static List<User_activity> listAllLogs() throws SQLException {
	        List<User_activity> logs = new ArrayList<>();
	        String sql = "SELECT ua.activity_id, ua.user_id, r.username, ua.last_login, " +
	                     "ua.total_time_spent_seconds, ua.status, ua.action " +
	                     "FROM user_activity ua " +
	                     "JOIN register r ON ua.user_id = r.id " +
	                     "ORDER BY ua.last_login DESC";

	        try (Connection c = DBConnection.getConnection();
	             PreparedStatement ps = c.prepareStatement(sql);
	             ResultSet rs = ps.executeQuery()) {

	            System.out.println("Fetching user activity logs...");
	            int count = 0;
	            
	            while (rs.next()) {
	                User_activity log = new User_activity();
	                log.setActivity_id(rs.getInt("activity_id"));
	                log.setUser_id(rs.getInt("user_id"));
	                log.setUsername(rs.getString("username"));
	                log.setLoginTime(rs.getTimestamp("last_login") != null ? rs.getTimestamp("last_login").toLocalDateTime() : null);
	                log.setTimeSpentSeconds(rs.getInt("total_time_spent_seconds"));
	                log.setAction(rs.getString("action"));
	                logs.add(log);
	                count++;
	            }
	            System.out.println("Retrieved " + count + " activity logs");
	        } catch (SQLException e) {
	            System.err.println("Error fetching activity logs");
	            throw e;
	        }
	        return logs;
	    }
	    
	    // Get activities for a specific user
	    public static List<User_activity> getUserActivities(int userId) throws SQLException {
	        List<User_activity> logs = new ArrayList<>();
	        String sql = "SELECT * FROM user_activity WHERE user_id = ? ORDER BY last_login DESC";
	        
	        try (Connection c = DBConnection.getConnection();
	             PreparedStatement ps = c.prepareStatement(sql)) {
	            ps.setInt(1, userId);
	            try (ResultSet rs = ps.executeQuery()) {
	                while (rs.next()) {
	                    User_activity log = new User_activity();
	                    log.setActivity_id(rs.getInt("activity_id"));
	                    log.setUser_id(rs.getInt("user_id"));
	                    log.setLoginTime(rs.getTimestamp("last_login") != null ? rs.getTimestamp("last_login").toLocalDateTime() : null);
	                    log.setTimeSpentSeconds(rs.getInt("total_time_spent_seconds"));
	                    log.setAction(rs.getString("action"));
	                    logs.add(log);
	                }
	            }
	        }
	        return logs;
	    }
	}
