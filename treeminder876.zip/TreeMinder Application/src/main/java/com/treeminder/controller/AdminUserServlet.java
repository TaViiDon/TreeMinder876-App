package com.treeminder.controller;


import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;

import com.treeminder.dao.RegisterDAO;
import com.treeminder.model.Register;

/**
 * Servlet implementation class AdminUserServlet
 */
@WebServlet("/adminusers")
public class AdminUserServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
	        resp.setContentType("application/json;charset=UTF-8");
	        try {
	            List<Register> users = RegisterDAO.listAll();
	            JSONArray arr = new JSONArray();
	            for (Register u : users) {
	                JSONObject o = new JSONObject();
	                o.put("id", u.getId());
	                o.put("firstname", u.getFirstname());
	                o.put("lastname", u.getLastname());
	                o.put("username", u.getUsername());
	                o.put("email", u.getEmail());
	                o.put("role", u.getRole());
	                o.put("mobile", u.getMobile());
	                o.put("parish", u.getParish());
	                o.put("nursery", u.getNursery());
	                o.put("created_at", u.getCreated_at() == null ? JSONObject.NULL : u.getCreated_at().toString());
	                o.put("lastLogin", JSONObject.NULL);
	                o.put("timeSpentSeconds", 0);
	                o.put("status", "active");
	                arr.put(o);
	            }
	            resp.getWriter().print(arr.toString());
	        } catch (Exception e) {
	            e.printStackTrace();
	            resp.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
	            resp.getWriter().print("[]");
	        }
	    }
	 protected void doDelete(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	        resp.setContentType("application/json;charset=UTF-8");
	        
	        String userId = req.getParameter("id");
	        if (userId == null) {
	            resp.setStatus(HttpServletResponse.SC_BAD_REQUEST);
	            resp.getWriter().print("{\"error\": \"User ID required\"}");
	            return;
	        }
	        
	        try {
	            int id = Integer.parseInt(userId);
	            boolean success = RegisterDAO.removeUser(id);
	            
	            if (success) {
	                resp.getWriter().print("{\"success\": true}");
	            } else {
	                resp.setStatus(HttpServletResponse.SC_BAD_REQUEST);
	                resp.getWriter().print("{\"error\": \"User not found\"}");
	            }
	            
	        } catch (Exception e) {
	            e.printStackTrace();
	            resp.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
	            resp.getWriter().print("{\"error\": \"Database error\"}");
	        }
	    }
	}