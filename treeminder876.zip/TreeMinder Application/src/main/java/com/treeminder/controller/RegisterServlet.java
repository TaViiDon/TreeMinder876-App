package com.treeminder.controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.SQLException;

import com.treeminder.dao.RegisterDAO;

/**
 * Servlet implementation class RegisterServlet
 */
@WebServlet("/register")
public class RegisterServlet extends HttpServlet {
	  private static final long serialVersionUID = 1L;

	    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	        req.setCharacterEncoding("UTF-8");
	        
	        // Get parameters from form
	        String firstname = req.getParameter("firstname");
	        String lastname = req.getParameter("lastname");
	        String username = req.getParameter("username");
	        String email = req.getParameter("email");
	        String password = req.getParameter("password");
	        String role = req.getParameter("accountType");
	        String mobile = req.getParameter("mobile");
	        String parish = req.getParameter("parish");
	        String nursery = req.getParameter("nursery");

	        System.out.println("Registration attempt - Username: " + username + 
                    ", Firstname: " + firstname + 
                    ", Lastname: " + lastname +
                    ", Mobile: " + mobile +
                    ", Parish: " + parish +
                    ", Nursery: " + nursery);
	        
	        // Validate required fields
	        if (firstname == null || firstname.trim().isEmpty() ||
	            lastname == null || lastname.trim().isEmpty() ||
	            username == null || username.trim().isEmpty() ||
	            email == null || email.trim().isEmpty() ||
	            password == null || password.trim().isEmpty() ||
	            role == null || role.trim().isEmpty() ||
	            mobile == null || mobile.trim().isEmpty() ||
	            parish == null || parish.trim().isEmpty() ||
	            nursery == null || nursery.trim().isEmpty()) {
	            
	            System.out.println("Missing required fields");
	            resp.sendRedirect("Register.html?error=missing_fields");
	            return;
	        }
	        
	        try {
	            // Check if username already exists
	            if (RegisterDAO.usernameExists(username)) {
	                System.out.println("Username already exists: " + username);
	                resp.sendRedirect("Register.html?error=username_exists");
	                return;
	            }

	            // Register the user
	            boolean success = RegisterDAO.register(firstname, lastname, username, email, password, role, mobile, parish, nursery);
	            
	            if (success) {
	                System.out.println("Registration successful for: " + username);
	                resp.sendRedirect("LoginPage.html?success=1");
	            } else {
	                System.out.println("Registration failed for: " + username);
	                resp.sendRedirect("Register.html?error=1");
	            }
	        } catch (SQLException e) {
	            e.printStackTrace();
	            System.out.println("Database error during registration: " + e.getMessage());
	            resp.sendRedirect("Register.html?error=database");
	        } catch (Exception e) {
	            e.printStackTrace();
	            System.out.println("Server error during registration: " + e.getMessage());
	            resp.sendRedirect("Register.html?error=server");
	        }
	    }
	}