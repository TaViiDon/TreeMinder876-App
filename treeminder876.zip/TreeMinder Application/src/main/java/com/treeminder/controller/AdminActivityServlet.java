package com.treeminder.controller;

import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;

import com.treeminder.dao.User_activityDAO;
import com.treeminder.model.User_activity;

/**
 * Servlet implementation class AdminActivityServlet
 */
@WebServlet("/adminactivity")
public class AdminActivityServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
	        resp.setContentType("application/json;charset=UTF-8");
	        try {
	            List<User_activity> logs = User_activityDAO.listAllLogs();
	            JSONArray arr = new JSONArray();
	            for (User_activity a : logs) {
	                JSONObject o = new JSONObject();
	                o.put("activity_id", a.getActivity_id());
	                o.put("user_id", a.getUser_id());
	                o.put("username", a.getUsername());
	                o.put("login_time", a.getLoginTime() == null ? JSONObject.NULL : a.getLoginTime().toString());
	                o.put("time_spent_seconds", a.getTimeSpentSeconds());
	                o.put("action", a.getAction());
	                arr.put(o);
	            }
	            resp.getWriter().print(arr.toString());
	        } catch (Exception e) {
	            e.printStackTrace();
	            resp.getWriter().print("[]");
	        }
	    }
	}