package com.treeminder.controller;

import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;

import com.treeminder.dao.User_activityDAO;
import com.treeminder.model.Register;

/**
 * Servlet implementation class LogoutServlet
 */
@WebServlet("/logout")
public class LogoutServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	  protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
	        HttpSession session = req.getSession(false);
	        if (session != null) {
	            Register reg = (Register) session.getAttribute("register");
	            if (reg != null) {
	                try {
	                    // update user_activity (logout) and update register.time_spent_seconds
	                    User_activityDAO.logLogout(reg.getId());
	                   // RegisterDAO.logoutAndAccumulateTime(reg.getId());
	                } catch (Exception e) {
	                    e.printStackTrace();
	                }
	            }
	            session.invalidate();
	        }
	        resp.sendRedirect(req.getContextPath() + "/LoginPage.html?logout=1");
	    }
	}
