package com.treeminder.controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;

import com.treeminder.dao.RegisterDAO;
import com.treeminder.dao.User_activityDAO;
import com.treeminder.model.Register;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/login")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	  protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	        req.setCharacterEncoding("UTF-8");
	        String username = req.getParameter("username");
	        String password = req.getParameter("password");
	        try {
	            Register reg = RegisterDAO.validate(username, password); // implement login in UserDAO
	            if (reg != null) {
	                HttpSession session = req.getSession();
	                session.setAttribute("register", reg);
	                session.setMaxInactiveInterval(30*60); // 30 minutes

	                // write activity log (user_activity table)
	                User_activityDAO.logLogin(reg.getId());

	                // redirect by role
	                if ("admin".equalsIgnoreCase(reg.getRole()) || "admin supplier".equalsIgnoreCase(reg.getRole())) {
	                    resp.sendRedirect(req.getContextPath() + "/AdminDashboard.html");
	                } //else {
	                   // resp.sendRedirect(req.getContextPath() + "/CustodianDashboard.html");
	               // }
	            } else {
	                resp.sendRedirect(req.getContextPath() + "/LoginPage.html?error=invalid");
	            }
	        } catch (Exception e) {
	            e.printStackTrace();
	            resp.sendRedirect(req.getContextPath() + "/LoginPage.html?error=server");
	        }
	    }
	}