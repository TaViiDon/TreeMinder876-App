package com.treeminder.model;

import java.time.LocalDateTime;

public class User_activity {
	private int activity_id;
    private int user_id;  // foreign key linking to Register
    private String username;
    private LocalDateTime loginTime;
    private int timeSpentSeconds;
    private String action; // description of the action



    public User_activity() {}

    public User_activity(int activity_id, int user_id,String username ,LocalDateTime loginTime, int timeSpentSeconds, String action) {
        this.setActivity_id(activity_id);
        this.setUser_id(user_id);
        this.setUsername(username);
        this.setLoginTime(loginTime);
        this.setTimeSpentSeconds(timeSpentSeconds);
        this.setAction(action);
    }

	
	public LocalDateTime getLoginTime() {
		return loginTime;
	}

	public void setLoginTime(LocalDateTime loginTime) {
		this.loginTime = loginTime;
	}


	public int getActivity_id() {
		return activity_id;
	}

	public void setActivity_id(int activity_id) {
		this.activity_id = activity_id;
	}

	public int getUser_id() {
		return user_id;
	}

	public void setUser_id(int user_id) {
		this.user_id = user_id;
	}

	public int getTimeSpentSeconds() {
		return timeSpentSeconds;
	}

	public void setTimeSpentSeconds(int timeSpentSeconds) {
		this.timeSpentSeconds = timeSpentSeconds;
	}

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}


	

    // Getters and setters...
}