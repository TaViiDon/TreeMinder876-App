document.addEventListener('DOMContentLoaded', function() {
    // Initialize the dashboard
    initAdminDashboard();
});

function initAdminDashboard() {
    console.log('Initializing admin dashboard...');

    // Menu toggle functionality
    const menuToggle = document.getElementById('menuToggle');
    const adminNav = document.getElementById('adminNav');
    if (menuToggle && adminNav) {
        menuToggle.addEventListener('click', function(e) {
            e.stopPropagation();
            adminNav.classList.toggle('show');
            document.body.classList.toggle('nav-open');
        });
        
        document.addEventListener('click', function(event) {
            if (adminNav.classList.contains('show') && !adminNav.contains(event.target) && event.target !== menuToggle) {
                adminNav.classList.remove('show');
                document.body.classList.remove('nav-open');
            }
        });
    }

    // User profile dropdown
    const userProfile = document.querySelector('.user-profile');
    const dropdownMenu = document.querySelector('.dropdown-menu');
    if (userProfile && dropdownMenu) {
        userProfile.addEventListener('click', function(e) {
            e.stopPropagation();
            dropdownMenu.classList.toggle('show');
        });
        
        document.addEventListener('click', function() {
            dropdownMenu.classList.remove('show');
        });
    }

    // Logout functionality
    const logoutLink = document.getElementById('logoutLink');
    if (logoutLink) {
        logoutLink.addEventListener('click', function(e) {
            e.preventDefault();
            sessionStorage.clear();
            window.location.href = 'LoginPage.html?logout=1';
        });
    }

    // Table switching functionality
    const viewUsersBtn = document.getElementById('viewUsersBtn');
    const trackActivityBtn = document.getElementById('trackActivityBtn');
    const usersTableSection = document.getElementById('usersTableSection');
    const activityTableSection = document.getElementById('activityTableSection');

    // View All Users button
    if (viewUsersBtn) {
        viewUsersBtn.addEventListener('click', function() {
            // Update button states
            viewUsersBtn.classList.remove('btn-secondary');
            viewUsersBtn.classList.add('btn-primary', 'active');
            trackActivityBtn.classList.remove('btn-primary', 'active');
            trackActivityBtn.classList.add('btn-secondary');
            
            // Show users table, hide activity table
            usersTableSection.style.display = 'block';
            activityTableSection.style.display = 'none';
            
            // Load users data
            loadUsersData();
        });
        
        // Load users on initial page load
        loadUsersData();
    }

    // Track User Activity button
    if (trackActivityBtn) {
        trackActivityBtn.addEventListener('click', function() {
            // Update button states
            trackActivityBtn.classList.remove('btn-secondary');
            trackActivityBtn.classList.add('btn-primary', 'active');
            viewUsersBtn.classList.remove('btn-primary', 'active');
            viewUsersBtn.classList.add('btn-secondary');
            
            // Show activity table, hide users table
            activityTableSection.style.display = 'block';
            usersTableSection.style.display = 'none';
            
            // Load activity data
            loadActivityData();
        });
    }

    // Modal functionality
    const modal = document.getElementById('userModal');
    const closeModalBtn = document.getElementById('closeModalBtn');
    const closeModalBtn2 = document.getElementById('closeModalBtn2');

    if (closeModalBtn && modal) {
        closeModalBtn.addEventListener('click', function() {
            modal.classList.remove('show');
        });
    }

    if (closeModalBtn2 && modal) {
        closeModalBtn2.addEventListener('click', function() {
            modal.classList.remove('show');
        });
    }

    window.addEventListener('click', function(event) {
        if (event.target === modal) {
            modal.classList.remove('show');
        }
    });

    // Tab functionality
    const tabButtons = document.querySelectorAll('.tab-btn');
    tabButtons.forEach(button => {
        button.addEventListener('click', function() {
            tabButtons.forEach(btn => btn.classList.remove('active'));
            this.classList.add('active');
        });
    });
}

// Load all users from server
function loadUsersData() {
    const usersTableBody = document.getElementById('usersTableBody');
    usersTableBody.innerHTML = '<tr><td colspan="11" class="loading">Loading users data...</td></tr>';
    
    fetch('adminusers')
        .then(response => {
            if (!response.ok) throw new Error('Network response was not ok');
            return response.json();
        })
        .then(users => {
            console.log('Users loaded:', users);
            displayUsers(users);
        })
        .catch(err => {
            console.error("Error loading users:", err);
            usersTableBody.innerHTML = '<tr><td colspan="11" style="text-align: center; color: #f44336;">Error loading users data</td></tr>';
        });
}

// Display users in table
function displayUsers(users) {
    const tbody = document.getElementById('usersTableBody');
    if (!tbody) return;
    
    tbody.innerHTML = "";
    
    if (users.length === 0) {
        tbody.innerHTML = '<tr><td colspan="11" style="text-align: center;">No users found</td></tr>';
        return;
    }

    users.forEach(user => {
        const row = document.createElement('tr');
        
        row.innerHTML = `
            <td>${user.id || '-'}</td>
            <td>${user.firstname || '-'}</td>
            <td>${user.lastname || '-'}</td>
            <td>${user.username || '-'}</td>
            <td>${user.email || '-'}</td>
            <td>${user.role || '-'}</td>
            <td>${user.mobile || '-'}</td>
            <td>${user.parish || '-'}</td>
            <td>${user.nursery || '-'}</td>
            <td>${user.created_at ? new Date(user.created_at).toLocaleDateString() : '-'}</td>
            <td>
                <button class="btn-icon view-user" data-userid="${user.id}" title="View Details">
                    <i class="fas fa-eye"></i>
                </button>
            </td>
        `;
        tbody.appendChild(row);
    });
    
    // Add event listeners to view buttons
    document.querySelectorAll('.view-user').forEach(button => {
        button.addEventListener('click', function() {
            const userId = this.getAttribute('data-userid');
            viewUserDetails(userId);
        });
    });
}

// Load user activities
function loadActivityData() {
    const activityTableBody = document.getElementById('activityTableBody');
    activityTableBody.innerHTML = '<tr><td colspan="6" class="loading">Loading activity data...</td></tr>';
    
    fetch('adminactivity')
        .then(response => {
            if (!response.ok) throw new Error('Network response was not ok');
            return response.json();
        })
        .then(activities => {
            console.log('Activities loaded:', activities);
            displayActivities(activities);
        })
        .catch(err => {
            console.error("Error loading activities:", err);
            activityTableBody.innerHTML = '<tr><td colspan="6" style="text-align: center; color: #f44336;">Error loading activity data</td></tr>';
        });
}

// Display activities in table
function displayActivities(activities) {
    const tbody = document.getElementById('activityTableBody');
    if (!tbody) return;
    
    tbody.innerHTML = "";
    
    if (activities.length === 0) {
        tbody.innerHTML = '<tr><td colspan="6" style="text-align: center;">No activity logs found</td></tr>';
        return;
    }

    activities.forEach(activity => {
        const row = document.createElement('tr');
        
        // Format time spent
        const timeSpent = activity.time_spent_seconds ? 
            formatTimeSpent(activity.time_spent_seconds) : '0m';
        
        // Determine status based on action
        const status = activity.action === 'login' ? 'Active' : 'Inactive';
        
        row.innerHTML = `
            <td>${activity.activity_id || '-'}</td>
            <td>${activity.user_id || '-'}</td>
            <td>${activity.login_time ? new Date(activity.login_time).toLocaleString() : 'Never'}</td>
            <td>${timeSpent}</td>
            <td>${activity.action || '-'}</td>
            <td><span class="status ${status.toLowerCase()}">${status}</span></td>
        `;
        tbody.appendChild(row);
    });
}

// Format time spent in seconds to readable format
function formatTimeSpent(seconds) {
    if (!seconds) return '0m';
    
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    
    if (hours > 0) {
        return `${hours}h ${minutes}m`;
    } else {
        return `${minutes}m`;
    }
}

// View user details in modal
function viewUserDetails(userId) {
    fetch('adminusers')
        .then(response => response.json())
        .then(users => {
            const user = users.find(u => u.id == userId);
            if (user) {
                // Populate modal with user details
                document.getElementById('detail-id').textContent = user.id || '-';
                document.getElementById('detail-firstname').textContent = user.firstname || '-';
                document.getElementById('detail-lastname').textContent = user.lastname || '-';
                document.getElementById('detail-username').textContent = user.username || '-';
                document.getElementById('detail-email').textContent = user.email || '-';
                document.getElementById('detail-role').textContent = user.role || '-';
                document.getElementById('detail-mobile').textContent = user.mobile || '-';
                document.getElementById('detail-parish').textContent = user.parish || '-';
                document.getElementById('detail-nursery').textContent = user.nursery || '-';
                document.getElementById('detail-created').textContent = 
                    user.created_at ? new Date(user.created_at).toLocaleDateString() : '-';
                
                // Show modal
                document.getElementById('userModal').classList.add('show');
            }
        })
        .catch(err => {
            console.error("Error loading user details:", err);
            alert('Error loading user details');
        });
}