document.addEventListener('DOMContentLoaded', function() {
    const step1Content = document.getElementById('step1Content');
    const step2Content = document.getElementById('step2Content');
    const nextStepBtn = document.getElementById('nextStep');
    const step1Indicator = document.getElementById('step1');
    const step2Indicator = document.getElementById('step2');
    const registrationForm = document.getElementById('registrationForm');

    console.log('DOM loaded - registration script running');

    // Move to step 2
    if (nextStepBtn) {
        nextStepBtn.addEventListener('click', function() {
            console.log('Next step button clicked');

            // Check if all required fields in step 1 are filled
            let allFilled = true;
            const requiredFields = step1Content.querySelectorAll('[required]');

            requiredFields.forEach(field => {
                if (!field.value.trim()) {
                    allFilled = false;
                    field.style.borderColor = 'red';
                } else {
                    field.style.borderColor = '#ddd';
                }
            });

            if (allFilled) {
                console.log('All fields filled, moving to step 2');
                step1Content.style.display = 'none';
                step2Content.style.display = 'block';
                step1Indicator.classList.remove('active');
                step2Indicator.classList.add('active');
            } else {
                console.log('Not all fields filled');
                alert('Please fill in all required fields before proceeding.');
            }
        });
    }

    // Form submission
    if (registrationForm) {
        registrationForm.addEventListener('submit', function(e) {
            e.preventDefault();
            console.log('Form submission');

            // Validate passwords match
            const password = document.getElementById('password').value;
            const confirmPassword = document.getElementById('confirmPassword').value;

            if (password !== confirmPassword) {
                alert('Passwords do not match!');
                return;
            }

            // Validate password strength
            if (!validatePassword(password)) {
                alert('Password does not meet the requirements!');
                return;
            }

            // Submit the form
            console.log('Submitting registration form...');
            this.submit();
        });
    }

    // Password validation
    function validatePassword(password) {
        // At least 8 characters
        if (password.length < 8) return false;

        // Mixture of uppercase and lowercase letters
        if (!/(?=.*[a-z])(?=.*[A-Z])/.test(password)) return false;

        // Mixture of letters and numbers
        if (!/(?=.*[a-zA-Z])(?=.*[0-9])/.test(password)) return false;

        // At least one special character
        if (!/(?=.*[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?])/.test(password)) return false;

        return true;
    }

    // Remove red border when user starts typing
    const inputs = document.querySelectorAll('input');
    inputs.forEach(input => {
        input.addEventListener('input', function() {
            this.style.borderColor = '#ddd';
        });
    });

    // Password visibility toggle
    const togglePassword = document.getElementById('togglePassword');
    if (togglePassword) {
        togglePassword.addEventListener('click', function() {
            const passwordInput = document.getElementById('password');
            const type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
            passwordInput.setAttribute('type', type);
            this.classList.toggle('fa-eye');
            this.classList.toggle('fa-eye-slash');
        });
    }
});