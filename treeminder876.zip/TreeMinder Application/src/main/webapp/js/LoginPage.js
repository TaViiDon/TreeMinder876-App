// Pre-set administrator credentials
//const adminCredentials = {
 //   username: "admin",
  //  password: "admin123"
//};

document.addEventListener('DOMContentLoaded', function () {
    console.log('Login page loaded - form will submit naturally to servlet');
    
    // Password toggle only
    const togglePassword = document.getElementById('togglePassword');
    const passwordInput = document.getElementById('password');
    if (togglePassword && passwordInput) {
        togglePassword.addEventListener('click', function () {
            const type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
            passwordInput.setAttribute('type', type);
            this.classList.toggle('fa-eye');
            this.classList.toggle('fa-eye-slash');
        });
    }

    // Show error message if present in URL
    const urlParams = new URLSearchParams(window.location.search);
    if (urlParams.has('error')) {
        const errorDiv = document.getElementById('errorMessage');
        if (errorDiv) {
            errorDiv.style.display = 'block';
            errorDiv.textContent = 'Invalid username or password';
        }
    }
    if (urlParams.has('success')) {
        alert('Registration successful! Please login.');
    }
    if (urlParams.has('logout')) {
        alert('You have been logged out successfully.');
    }
});